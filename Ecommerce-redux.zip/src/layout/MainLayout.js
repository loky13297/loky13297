import Footer from 'pages/CrudForm/Footer'
import { Header } from 'pages/CrudForm/Header'
import React, { Component } from 'react'


export class MainLayout extends Component {

    render() {

        let { children } = this.props

        return (

            <>
                <Header />
                {children}
                <Footer></Footer>
            </>
        )
    }
}
