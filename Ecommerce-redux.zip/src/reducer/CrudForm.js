import { CrudActionType } from "service/actionType"


import logo from '../assets/images/shirt.jpg'

const initialState = {
    listData: [

        {
            id: 1,
            name: 'man t-shirt',
            image: logo,
            price: 300,
            discount: 500,
            quantity: 1,
        },
        {
            id: 2,
            name: 'woman jacket',
            image: logo,
            price: 500,
            discount: 800,
            quantity: 1,
        },
        {
            id: 3,
            name: 'man trouser',
            image: logo,
            price: 700,
            discount: 900,
            quantity: 1,
        },

        {
            id: 4,
            name: 'shoes',
            image: logo,
            price: 600,
            discount: 900,
            quantity: 1,
        },
    ],
    cart: []
}

export default (state = initialState, { type, payload }) => {
    switch (type) {
        case CrudActionType.getFormData:
            return {
                // ...state,
            }
        case CrudActionType.addCart: {
            console.log(payload)
            return { ...state, cart: [...state.cart, payload] }
        }
        case CrudActionType.deleteFormData:
            // console.log(...state)

            return {
                ...state,
                cart: state.cart.filter((item, index) => index !== payload)

            }





        default:
            return state
    }
}