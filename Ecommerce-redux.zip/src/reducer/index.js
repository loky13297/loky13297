import { combineReducers } from "redux";
import CrudForm from "./CrudForm"

export const reducers = combineReducers({
    CrudForm
})