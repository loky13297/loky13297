import React, { Component } from "react";
import "../../App.css";
import { Button, Modal, ModalHeader, ModalBody, ModalFooter, Input } from 'reactstrap';
// import 'assets/images';
import { getAddDetails, getEditDetails, getDeleteDetails, getDetails, deleteFormData, updateFormData } from "action/CrudForm"
import { connect } from 'react-redux';
import { bindActionCreators } from "redux"
import { FaSearch } from 'react-icons/fa'
import { FaPhoneAlt } from 'react-icons/fa';
import { AiOutlineHeart } from 'react-icons/ai'
import { AiFillStar } from 'react-icons/ai'
import { filterByValue, sortByAlphabat } from '../../action/CrudForm'
import { FiUser } from 'react-icons/fi'
import { AiOutlineShoppingCart } from 'react-icons/ai'
import apple from "assets/images/apple.png";
import google from "assets/images/google.png";
import Header from './Header'

import { Link } from "react-router-dom";
import Container from "reactstrap/lib/Container";
import Footer from "./Footer";

export class CrudFormClass extends Component {
    constructor(props) {
        super(props);

        this.state = {

            list: props.list,




        }
    };




    // componentDidMount() {
    //     let data = this.state.list.filter(obj => { return obj.id === 1 })
    //     console.log(data)
    // }


    lowPrice() {
        let lowToHigh = this.state.list.sort((a, b) => {
            return a.price - b.price;
        })
        this.setState({
            list: lowToHigh
        })
    }
    highPrice() {
        let highToLow = this.state.list.sort((a, b) => {
            return b.price - a.price
        })
        this.setState({
            list: highToLow
        })
    }

    myChange = (e) => {
        if (e.target.value == "Low to high") {
            this.lowPrice()
        } else {
            this.highPrice()
        }
    }

    render() {



        return (

            <div>
                <div className="container foot">

                    <div className="row py-4">
                        <div className="col-md-12 d-flex justify-content-end">
                            <select className=" dropdown" onChange={this.myChange} defaultValue=" ">
                                <option value="" >Default Shorting</option>

                                <option value="Low to high">Low to high</option>
                                <option value=" High to low">High to low</option>
                            </select>
                        </div>
                    </div>
                    <div className="checkoutsep"></div>

                </div>

                {/* <button onClick={() => this.lowPrice()}>low</button>
                <button onClick={() => this.highPrice()}>high</button> */}



                <div class="container cards">
                    <div className="row py-5 contents">
                        {this.props.list.map((data, index) => {
                            // console.log(data.name)
                            return (
                                <div key={index} onClick={() => this.props.history.push({
                                    pathname: '/crud/details',
                                    data: data.id,
                                })}

                                    className="col-md-3 ">
                                    <img className="imagewidth" src={data.image} />

                                    <p className="p-0 m-0">{data.name}</p>
                                    <span className="stars"><AiFillStar /><AiFillStar /><AiFillStar /><AiFillStar /><AiFillStar /></span>
                                    <p>Rs:{data.price}&nbsp;&nbsp;&nbsp;&nbsp;<strike className="strike">Rs:{data.discount}</strike></p>



                                </div>

                            );
                        })}
                    </div>
                </div>

            </div>
        );
    }
}



const mapStateToProps = (state) => {
    console.log(state.CrudForm.cart.length)
    return {
        cartBadge: state.CrudForm.cart.length,
        list: state.CrudForm.listData
    }
}

const mapDispatchToProps = dispatch => {
    return bindActionCreators({
        // deleteFormData,

    }, dispatch)
}


export const CrudForm = connect(mapStateToProps, mapDispatchToProps)(CrudFormClass)
