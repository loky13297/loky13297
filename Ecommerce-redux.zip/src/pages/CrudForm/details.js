import React, { Component } from "react";
import "../../App.css";
import { Button, Modal, ModalHeader, ModalBody, ModalFooter, Input } from 'reactstrap';

import { getAddDetails, getEditDetails, getDeleteDetails, getDetails, deleteFormData, updateFormData, addCart } from "action/CrudForm"
// import * as  from "action/CrudForm";
import { connect } from 'react-redux';
import { bindActionCreators } from "redux"
import { FaSearch } from 'react-icons/fa'
import { FaPhoneAlt } from 'react-icons/fa';
import { AiOutlineHeart } from 'react-icons/ai'
import { AiFillStar } from 'react-icons/ai'
import { filterByValue, sortByAlphabat } from '../../action/CrudForm'
import { FiUser } from 'react-icons/fi'
import { AiOutlineShoppingCart } from 'react-icons/ai'
import { Link } from "react-router-dom";
import apple from "assets/images/apple.png";
import google from "assets/images/google.png";
import { Header } from './Header'
import Footer from './Footer'

export class DetailsScreen extends Component {
    constructor(props) {
        super(props);

        this.state = {

            list: [],


        }
    };




    componentDidMount() {
        // let data = this.props.list.filter(obj => { return obj.id === this.props.location.data });
        // console.log(data)
        // this.setState({ list: data })
        this.filteredValue();
    }
    filteredValue() {
        let data = this.props.list.filter(obj => { return obj.id === this.props.location.data });
        // console.log(data)
        this.setState({ list: data })
    }
    addCart(cart) {
        console.log(cart)
        this.props.actions.addCart(cart)
    }



    render() {



        return (

            <div>

                <div className="container detailcont py-5">
                    <div class="row">
                        <div class="col-md-12">
                            {/* <span>
                            {this.state.list[0]}
                        </span> */}




                            {this.state.list.map((data, index) => {
                                // console.log(data.name)
                                return (
                                    <div key={index}
                                        className="row"
                                    >
                                        <img className="imagewidth-details" src={data.image} />
                                        <div className="col-md-6 img">
                                            {/* <div className="col-md-6"> */}

                                            <h3 className="p-0 m-0">{data.name}</h3>
                                            <span className="stars"><AiFillStar /><AiFillStar /><AiFillStar /><AiFillStar /><AiFillStar /></span>
                                            <p>Rs:{data.price}&nbsp;&nbsp;&nbsp;&nbsp;<strike className="strike">Rs:{data.discount}</strike></p>
                                            <div className="row">
                                                <div className="col-md-3">
                                                    <p className="available-size py-2">Available size</p>
                                                </div>
                                                <div className="col-md-7  p-0 m-0">
                                                    <ul class="nav justify-content-start">
                                                        <li class="nav-item ">
                                                            <a class="nav-link p-0 m-0" ><button className="sizes">S</button></a>
                                                        </li>
                                                        <li class="nav-item  ">
                                                            <a class="nav-link p-0 m-0 ml-2" ><button className="medium">M</button></a>
                                                        </li>
                                                        <li class="nav-item ">
                                                            <a class="nav-link p-0 m-0 ml-2" ><button className="large">L</button></a>
                                                        </li>
                                                        <li class="nav-item ">
                                                            <a class="nav-link p-0 m-0 ml-2" ><button className="xl">XL</button></a>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                            <div className="row">
                                                <div className="col-md-3">
                                                    <p className="available-size py-2">Available color</p>

                                                </div>
                                                <div className="col-md-7">
                                                    <ul class="nav justify-content-start py-2 p-0 m-0">
                                                        <li class="nav-item ">
                                                            <div className="box red"></div>
                                                        </li>
                                                        <li class="nav-item  ">
                                                            <div className="box blue ml-2"></div>
                                                        </li>
                                                        <li class="nav-item ">
                                                            <div className="box green ml-2"></div>
                                                        </li>
                                                        <li class="nav-item ">
                                                            <div className="box yellow ml-2"></div>
                                                        </li>
                                                    </ul>
                                                </div>

                                            </div>
                                            <div>
                                                <button onClick={() => this.addCart(data)} className="addtocart">Add to cart</button>

                                            </div>

                                        </div>


                                    </div>

                                );
                            })}
                        </div>


                    </div>
                </div>



            </div >
        );
    }
}



function mapStateToProps(state) {
    return {
        list: state.CrudForm.listData,
        cartBadge: state.CrudForm.cart.length,

    }
}

function mapDispatchToProps(dispatch) {
    return {
        actions: bindActionCreators({
            getAddDetails,
            filterByValue,
            sortByAlphabat,
            addCart,

            getDetails
        }, dispatch)
    }
}


export const Details = connect(mapStateToProps, mapDispatchToProps)(DetailsScreen)