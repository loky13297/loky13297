
import React, { Component } from "react";
import "../../App.css";
import { Button, Modal, ModalHeader, ModalBody, ModalFooter, Input } from 'reactstrap';

import { getAddDetails, getEditDetails, getDeleteDetails, getDetails, deleteFormData, updateFormData, addCart } from "action/CrudForm"
import { connect } from 'react-redux';
import { bindActionCreators } from "redux"
import { FaSearch } from 'react-icons/fa'
import { FaPhoneAlt } from 'react-icons/fa';
import { AiOutlineHeart } from 'react-icons/ai'
import { AiFillStar } from 'react-icons/ai'
import { filterByValue, sortByAlphabat } from '../../action/CrudForm'
import { FiUser } from 'react-icons/fi'
import { AiOutlineShoppingCart } from 'react-icons/ai'
import { Link } from "react-router-dom";
import apple from "assets/images/apple.png";
import google from "assets/images/google.png";
import { AiFillDelete } from "react-icons/ai";
import { Header } from './Header'
import Footer from './Footer'


export class Cart extends Component {
    constructor(props) {
        super(props);

        this.state = {

            // list: props.list,
            // cartProduct: [],
            name: "",
            email: "",
            nameError: "",
            emailError: "",

        }
    };




    componentDidMount() {


    }

    deleteData = (index) => {
        this.props.actions.getDeleteDetails(index);

    }
    validate = () => {
        var reEmail = /^(?:[\w\!\#\$\%\&\'\*\+\-\/\=\?\^\`\{\|\}\~]+\.)*[\w\!\#\$\%\&\'\*\+\-\/\=\?\^\`\{\|\}\~]+@(?:(?:(?:[a-zA-Z0-9](?:[a-zA-Z0-9\-](?!\.)){0,61}[a-zA-Z0-9]?\.)+[a-zA-Z0-9](?:[a-zA-Z0-9\-](?!$)){0,61}[a-zA-Z0-9]?)|(?:\[(?:(?:[01]?\d{1,2}|2[0-4]\d|25[0-5])\.){3}(?:[01]?\d{1,2}|2[0-4]\d|25[0-5])\]))$/;
        let nameError = "";
        let emailError = "";



        const { name, email, } = this.state;
        if (!name) {
            nameError = "name cannot be blank";
        }



        if (!email.match(reEmail)) {
            emailError = "Invalid email address";

        }




        if (emailError || nameError) {
            this.setState({ emailError, nameError });
            return false;
        }

        return true;


    };
    submit() {
        // e.preventDefault();

        const isValid = this.validate();
        if (isValid) {
            const { name, email } = this.state;

            if (this.state.name && this.state.email) {
                alert("your order is successfull  ")

            }



        }
    }

    handleChange = (e) => {
        this.setState({

            [e.target.name]: e.target.value
        });
    }
    render() {

        let total = this.props.cartProduct.reduce((current, previous) => {
            // console.log(current, previous.price)
            return current + previous.price;
        }, 0)

        return (

            <div>



                <div className="container pt-4">
                    {/* {this.props.cartProduct.map((data, index) => {
                        return (
                            <div key={index}>

                                {data.price}
                                <button onClick={() => this.deleteData(index)}>delete</button>
                            </div>
                        )
                    })} */}
                    <center>
                        <div >
                            <table>
                                <thead>
                                    <tr>
                                        <th>Prodect Details</th>
                                        <th>Price</th>
                                        <th>Total</th>
                                        {/* <th>Number</th> */}
                                    </tr>
                                </thead>

                                <tbody >
                                    {this.props.cartProduct.map((data, index) => {
                                        return <tr key={(index)}>

                                            <td>
                                                <div className="row">
                                                    <div className="col-md-6 p-0 m-0">
                                                        <img className="cartImg" src={data.image} />
                                                    </div>
                                                    <div className="col-md-6 p-0 m-0">
                                                        <td className="productName"> {data && data.name}</td>

                                                    </div>
                                                </div>
                                            </td>
                                            <td>Rs:{data && data.price}</td>
                                            <td>Rs:{data && data.price}</td>
                                            {/* <td>{data && data.img}</td> */}
                                            <td><AiFillDelete size="25" className="deleteIcon" onClick={() => this.deleteData(index)} /></td>
                                            {/* <button>delete</button> */}
                                            <td></td>

                                        </tr>
                                    })}
                                </tbody>
                            </table>
                        </div>
                    </center>


                    <div className="container mt-5 mb-5 foot checkoutbg">
                        <div className="container ">
                            <p className="ordersummary pt-4 pb-2">
                                Order Summary
                        </p>
                            <div className="checkoutsep"></div>
                            <div className="row">
                                <div className="col-md-6">
                                    <form>
                                        <div className="py-4">
                                            <div>
                                                <label className="checkboxhead">Enter your name</label>


                                            </div>
                                            {/* <input type="text" className="checkboxsearch"></input> */}
                                            <input onChange={this.handleChange} className="checkboxsearch" name="name" value={this.state.name} type="text" />

                                            <div class="form-validationError">{this.state.nameError}</div>

                                        </div>
                                        <div>
                                            <label className="checkboxhead">Enter your Email</label>

                                        </div>
                                        {/* <input type="text" className="checkboxsearch"></input> */}
                                        <input onChange={this.handleChange} className="checkboxsearch" name="email" value={this.state.email} type="email" />

                                        <div class="form-validationError">{this.state.emailError}</div>
                                        {/* 
                                        <div className="pt-4 pb-5">
                                            <button className="applybutton">Apply</button>
                                        </div> */}
                                    </form>
                                </div>
                                <div className="col-md-6 ">
                                    <div className="d-flex justify-content-end pt-4 pb-2">
                                        <p>
                                            Total Item:{this.props.cartBadge}
                                            <div>
                                                <p className="pt-3">Sub Total:{total}Rs</p>
                                            </div>
                                        </p>
                                    </div>
                                    <div className="checksep ml-auto"></div>
                                    <p className="d-flex justify-content-end pt-4">Total Cost:{total}Rs</p>
                                    <div className="pt-4 p-0 m-0 checkoutbut">
                                        <button className="mt-1 checkred" onClick={() => this.submit()}>CheckOut</button>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>


            </div >
        );
    }
}



const mapStateToProps = (state) => {
    console.log(state)
    return {
        cartBadge: state.CrudForm.cart.length,

        cartProduct: state.CrudForm.cart
    }
}

function mapDispatchToProps(dispatch) {
    return {
        actions: bindActionCreators({
            // getAddDetails,

            addCart,
            getDeleteDetails,

            // getDetails
        }, dispatch)
    }
}


export const cart = connect(mapStateToProps, mapDispatchToProps)(Cart)