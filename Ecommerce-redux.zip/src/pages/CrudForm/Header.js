import React, { Component } from 'react'
import "../../App.css";
import { Button, Modal, ModalHeader, ModalBody, ModalFooter, Input } from 'reactstrap';
// import 'assets/images';
import { getAddDetails, getEditDetails, getDeleteDetails, getDetails, deleteFormData, updateFormData, cartBadge, addCart } from "action/CrudForm"
import { connect } from 'react-redux';
import { bindActionCreators } from "redux"
import { FaSearch } from 'react-icons/fa'
import { FaPhoneAlt } from 'react-icons/fa';
import { AiOutlineHeart } from 'react-icons/ai'
import { AiFillStar } from 'react-icons/ai'
import { filterByValue, sortByAlphabat } from '../../action/CrudForm'
import { FiUser } from 'react-icons/fi'
import { AiOutlineShoppingCart } from 'react-icons/ai'
import apple from "assets/images/apple.png";
import google from "assets/images/google.png";
import { Link } from "react-router-dom";
import Container from "reactstrap/lib/Container";

class Head extends Component {
    // addCart(cart) {
    //     console.log(cart)
    //     this.props.actions.addCart(cart)
    // }
    constructor(props) {
        super(props);

        this.state = {

            // list: props.list,
            // cartProduct: [],
            // name: "",
            // email: "",
            // nameError: "",
            // emailError: "",

        }
    };


    componentDidMount() {

    }

    render() {
        return (
            <div>

                <div class="container-fluid fridaybanner py-1 pt-2">
                    <p>Black Friday Banner</p>

                </div>
                <div className="container navconta">
                    <div class="container row ">
                        <div class="col-md-4 p-0 m-0 logo ">
                            <ul class="d-flex justify-content-start py-2 p-0 m-0 shopping-cart">
                                <li>
                                    <p>Welcome to shopping mart!</p>
                                </li>
                            </ul>
                        </div>
                        <div class="col-md-8 p-0 m-0">
                            <ul class="nav justify-content-end py-0 pt-0">
                                <li class="nav-item">
                                    <a class="nav-link navcolor  " href="#">Home</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link navcolor pl-4 " href="#">Shop</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link navcolor pl-4" href="#">Prodect</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link navcolor pl-4" href="#">Categories</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link navcolor pl-4" href="#">Brand </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link navcolor pl-4" href="#">About</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="row py-3">
                        <div class="col-md-2">
                            <h3 className="logoname">mimingo</h3>
                        </div>
                        <div class="col-md-2 contacts">
                            <div class="row pt-2">
                                <div class="col-md-3 contacts pt-1">
                                    <FaPhoneAlt />
                                </div>
                                <div class="col-md-9 p-0 m-0 ">
                                    <div>
                                        <p class="contact p-0 m-0 ">Contact Us</p>
                                    </div>
                                    <div>
                                        <p class="number p-0 m-0 pt-1 ">+12345678</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 p-0 m-0 pt-2">
                            <div class="input-group">
                                <input type="text" class=" searchbox" aria-label="search here" aria-describedby="button-search" />
                                <button class="btn" type="button" id="button-search"><FaSearch /></button>

                            </div>

                        </div>
                        <div class="col-md-4 py-2 icons">
                            <FiUser size="20" className="usericon" />
                            <AiOutlineHeart size="20" className="hearticon" />
                            <Link className="carticon" to={{ pathname: '/crud/cart' }}>
                                <AiOutlineShoppingCart size="20" /></Link>
                            <span className="productBadge">{this.props.cartBadge}</span>
                        </div>

                    </div>
                </div>

                <div class="container-fluid p-0 m-0 pt-2 ">

                    <nav aria-label="breadcrumb ">

                        <ul class="breadcrumb tabs py-5 ">
                            <div className="col-md-12 d-flex justify-content-center">
                                <p className="shop pt-2 p-0 m-0">Shop</p>
                            </div>

                            <Link to={`/crud/create`} className="homelink"><li class="breadcrumb-item bread p-0 m-0">Home&nbsp;&nbsp;/&nbsp;&nbsp;</li></Link>
                            <li class="breadcrumb-item  bread " aria-current="page">Shop</li>
                        </ul>
                    </nav>


                </div>
            </div>
        )
    }
}
const mapStateToProps = (state) => {
    return {
        cartBadge: state.CrudForm.cart.length
    }
}
const mapDispatchToProps = dispatch => {
    return bindActionCreators({
        // deleteFormData,

    }, dispatch)
}

export const Header = connect(mapStateToProps, mapDispatchToProps)(Head)
