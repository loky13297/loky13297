import React, { Component } from 'react';
import "../../App.css";
import { Button, Modal, ModalHeader, ModalBody, ModalFooter, Input } from 'reactstrap';

import { getAddDetails, getEditDetails, getDeleteDetails, getDetails, deleteFormData, updateFormData, addCart } from "action/CrudForm"
// import * as  from "action/CrudForm";
import { connect } from 'react-redux';
import { bindActionCreators } from "redux"
import { FaSearch } from 'react-icons/fa'
import { FaPhoneAlt } from 'react-icons/fa';
import { AiOutlineHeart } from 'react-icons/ai'
import { AiFillStar } from 'react-icons/ai'
import { filterByValue, sortByAlphabat } from '../../action/CrudForm'
import { FiUser } from 'react-icons/fi'
import { AiOutlineShoppingCart } from 'react-icons/ai'
import { Link } from "react-router-dom";
import apple from "assets/images/apple.png";
import google from "assets/images/google.png";
import Header from './Header'


export default class Footer extends Component {
    render() {
        return (
            <div>
                <div className="container-fluid footer p-0 m-0">
                    <div className="container ">
                        <div className="row py-5">
                            <div className="col-md-4 subcribenow pt-1 p-0 m-0">

                                <p className="subcribenow">Subscribe Now</p>
                            </div>
                            <div className="col-md-4 footersearch">
                                <div class="input-group">
                                    <input type="text" placeholder="enter your email for next update" className="footsearch"></input>

                                </div>
                            </div>
                            <div className="col-lg-4 signin">
                                <button class="btnn signup" type="button" >SIGN UP</button>

                            </div>
                        </div>
                    </div >
                    <div className="footerline"></div>


                    <div className="container-fluid">
                        <div className=" container py-5 foot">
                            <div class="row py-3">
                                <div className="col-md-4 p-0 m-0 px-auto">
                                    <h5 className="foothead">LOGO</h5>
                                    <p className="pt-4 footpara">Download the app for easy order</p>
                                    <p className="col-md-10 p-0 m-0 footpara">Lorem Ipsum is simple dummy text of the printing and typesetting industry.</p>
                                    <div className="row pt-4">
                                        <div className="col-md-5">
                                            <img src={apple} className="apps"></img>
                                        </div>
                                        <div className="col-md-5">
                                            <img src={google} className="apps"></img>

                                        </div>
                                    </div>
                                </div>

                                <div className="col-md-3 abt1">
                                    <h5 className="foothead">About us</h5>
                                    <ul className="p-0 m-0 pt-4 height">
                                        <li>Blog</li>
                                        <li>Working Process</li>
                                        <li>Food</li>
                                        <li>Restaurants</li>
                                        <li>Delivery</li>
                                    </ul>
                                </div>
                                <div className="col-md-3  height">
                                    <h5 className="foothead">About us</h5>
                                    <ul className="p-0 m-0 pt-4" >
                                        <li>Blog</li>
                                        <li>Working Process</li>
                                        <li>Food</li>
                                        <li>Restaurants</li>
                                        <li>Delivery</li>
                                    </ul>
                                </div>
                                <div className="col-md-2 px-auto height">
                                    <h5 className="foothead">Get help</h5>
                                    <ul className="p-0 m-0 pt-4">
                                        <li>Blog</li>
                                        <li>Working Process</li>
                                        <li>Food</li>
                                        <li>Restaurants</li>
                                        <li>Delivery</li>
                                    </ul>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div className="footerline"></div>
                    <div className="container-fluid">
                        <div className="container pl-0 py-3 foot">
                            <p className="p-0 m-0 foothead">Copyright&copy; All right reserved</p>

                        </div>
                    </div>
                </div>
            </div>
        )
    }
}
