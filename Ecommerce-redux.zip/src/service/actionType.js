export const CrudActionType = {
    addFormData: 'ADD_FORM_DATA',
    editFormData: 'EDIT_FORM_DATA',
    deleteFormData: 'DELETE_FORM_DATA',
    getFormData: 'GET_FORM_DATA',
    sortByAlphabet: "SORT_BY_ALPHABET",
    filterByValue: 'FILTER_BY_VALUE',
    sortByAlphabat: "SORT_BY_ALPHABET",
    addCart: "ADD_CART"
}