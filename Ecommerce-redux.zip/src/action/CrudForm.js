import { CrudActionType } from "service/actionType"


export const getAddDetails = (data) => (dispatch) => {
    return new Promise((resolve, reject) => {
        dispatch({
            type: CrudActionType.addFormData,
            payload: data
        })
    })
}
export const filterByValue = (data) => (dispatch) => {
    return new Promise((resolve, reject) => {
        dispatch({
            type: CrudActionType.filterByValue,
            payload: data
        })
    })
}
export const sortByAlphabat = (data) => (dispatch) => {
    return new Promise((resolve, reject) => {
        dispatch({
            type: CrudActionType.sortByAlphabat,
            payload: data
        })
    })
}
export const getDeleteDetails = (data) => (dispatch) => {
    console.log(data)
    return new Promise((resolve, reject) => {
        dispatch({
            type: CrudActionType.deleteFormData,
            payload: data
        })
    })
}


export const addCart = (data) => (dispatch) => {
    console.log(data)

    return new Promise((resolve, reject) => {

        dispatch({
            type: CrudActionType.addCart,
            payload: data
        })
    })
}




export const getDetails = () => (dispatch) => {
    return new Promise((resolve, reject) => {
        dispatch({
            type: CrudActionType.getFormData
        })
    })
}

